export * from "./res.interface";
export * from "./base-entity";