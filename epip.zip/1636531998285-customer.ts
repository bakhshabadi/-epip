import {MigrationInterface, QueryRunner} from "typeorm";

export class customer1636531998285 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<void> {
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
    }

}
