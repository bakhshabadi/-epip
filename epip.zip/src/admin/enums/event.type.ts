export class ConstService {
    public static EventStatus = {
        buySubscribe: "خرید اشتراک تست انجام شده و پیگیری اپراتور",
        notWantToTracking: "به دلایلی موفق به پیگیری مشتری نشده ایم",
        notWantToSubscribe: "به دلایلی اشتراک نخواسته است",
        buyFinalSubscribe: "خرید اشتراک پولی انجام شد",
        sendSurvay: "ارسال پیامک نظرسنجی",
        avanakCall: "تماس صوتی آوانک",
        trackOrder: "پیگیری سفارش خرید",
    }
}