export enum TemplateType{
    VerifyPassword= "verifypassword",
    OpportunityWorkflow= "Opportunity-workflow",
    Survey= "survey",
    Welcome= "welcome",
}