import {MigrationInterface, QueryRunner} from "typeorm";

export class filing1637396102250 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<void> {
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
    }

}
